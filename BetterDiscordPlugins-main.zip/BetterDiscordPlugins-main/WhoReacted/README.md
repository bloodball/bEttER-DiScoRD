# WhoReacted

A plugin that shows the avatars of the users who reacted to a message.

![Demo](https://i.imgur.com/Gg56Z1v.png)