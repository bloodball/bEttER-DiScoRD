# BetterDiscordPlugins

Some plugins that I made for [BetterDiscord](https://betterdiscord.net/).

- [BiggerStreamPreview](https://github.com/jaimeadf/BetterDiscordPlugins/tree/main/BiggerStreamPreview) - Allows you to see bigger previews of streams via the context menu.
- [WhoReacted](https://github.com/jaimeadf/BetterDiscordPlugins/tree/main/WhoReacted) - Shows the avatars of the users who reacted to a message.