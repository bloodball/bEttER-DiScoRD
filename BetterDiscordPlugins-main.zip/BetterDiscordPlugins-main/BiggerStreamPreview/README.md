# BiggerStreamPreview

A plugin that allows you to see bigger previews of streams via the context menu.

![Demo](https://i.imgur.com/nWoOCCA.gif)