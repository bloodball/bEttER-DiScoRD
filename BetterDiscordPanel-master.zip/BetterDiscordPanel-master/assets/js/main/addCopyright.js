/**
 * @file addCopyright.js
 * @author Sanjay Sunil (a.k.a D3VSJ)
 * @license GPL-3.0
 */

$('.000').replaceWith('Copyright © 2020');
$('.001').replaceWith('Sanjay Sunil');
$('.002').replaceWith('All rights reserved.');