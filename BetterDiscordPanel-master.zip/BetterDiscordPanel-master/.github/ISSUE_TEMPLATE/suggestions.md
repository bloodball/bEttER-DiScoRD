---
name: Suggestions 
about: Here you can make suggestions for the BetterDiscordPanel Project. If you would like to create a suggestion through Discord, join the official BetterDiscordPanel server here. https://discord.gg/5SAVPAj
title: "[SUGGESTION]"
labels: Suggestions
assignees: ''

---

#### Suggestion Type
- Type: 

- Description: 

#### How would it help?

#### Preview of the change
- Screenshots:

- Script:
