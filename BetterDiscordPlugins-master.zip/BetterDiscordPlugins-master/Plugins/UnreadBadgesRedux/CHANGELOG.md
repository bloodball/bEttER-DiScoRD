# [UnreadBadgesRedux](https://1lighty.github.io/BetterDiscordStuff/?plugin=UnreadBadgesRedux "UnreadBadgesRedux") Changelog
### 1.0.10
- Fixed not working on folders.

### 1.0.9
- Fixed not working on channels.

### 1.0.8
- Fixed not working on channels.

### 1.0.7
- Fixed not working on canary.

### 1.0.6
- Changed to module.exports because useless backwards incompatbile changes are the motto for BBD apparently.

### 1.0.5
- Fixed badge not showing on folders, again

### 1.0.4
- Fixed badge not showing on folders on Discord canary

### 1.0.3
- Temp fixed a bug caused by ZLib, making the badges not show

### 1.0.2
- Heavily optimized the plugin, expect better performance if you have lots of servers

### 1.0.1
- Fixed crash if XenoLib or ZeresPluginLib were missing

### 1.0.0
- Initial release
- Redux has been released!
- That is all. I don't think much else needs to be said here, does it? It Just Works(tm).
- Oh yeah, I added a ton of options so have fun with that.
