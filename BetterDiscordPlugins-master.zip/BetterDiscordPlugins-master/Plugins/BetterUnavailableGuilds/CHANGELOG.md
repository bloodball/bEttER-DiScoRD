# [BetterUnavailableGuilds](https://1lighty.github.io/BetterDiscordStuff/?plugin=BetterUnavailableGuilds "BetterUnavailableGuilds") Changelog
### 0.2.9
- Fixed not restoring the servers on startup.

### 0.2.8
- Changed to module.exports because useless backwards incompatbile changes are the motto for BBD apparently.

### 0.2.7
- Fixed rare bug when client reconnects.

### 0.2.6
- Fixed error spam that was so fast, devtools froze

### 0.2.5
- Fixed settings menu not displaying an input
- Removed unneeded Xenolib dependency

### 0.2.4
- Fixed plugin failing to transfer data from canary to other release channels

### 0.2.3
- Fixed crash if XenoLib or ZeresPluginLib were missing

### 0.2.2
- Fixed plugin not working AT ALL in ED
- Fixed a specific error where plugin loaded, but you are not logged in yet

### 0.2.1
- Fixed plugin completely failing to load if no config is present

### 0.2.0
- Now supports multiple users at once, and multiple clients at once, also multiple release channels at once
- Reinserts missing servers even when logging out or when websocket dies
- Added a method of adding missing servers and a way to share them to others that need it
- Added BetterDiscord and BetterDiscord2 servers as pre cached servers for convenience sake

### 0.1.0
- Initial release
