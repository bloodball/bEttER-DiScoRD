# [MultiUploads](https://1lighty.github.io/BetterDiscordStuff/?plugin=MultiUploads "MultiUploads") Changelog

### 1.1.2
- Fixed not being able to send multiple files with identical names (woops).
Never noticed this bug due to another plugin randomizing all uploaded filenames, my bad!

### 1.1.1
- Fixed not being able to use the reply feature and send a file at the same time.

### 1.1.0
- Added ability to paste multiple times.

### 1.0.0
- Multiple uploads send in a single message, like on mobile. Hold shift while pressing the upload button to only upload one.
