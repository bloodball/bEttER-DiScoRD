# [BetterTypingUsers](https://1lighty.github.io/BetterDiscordStuff/?plugin=BetterTypingUsers "BetterTypingUsers") Changelog
### 1.0.1
- Changed to module.exports because useless backwards incompatbile changes are the motto for BBD apparently.

### 1.0.0
- Initial release
- Max users typing changed to 5, with showing and "x others" if more people than that are typing.
