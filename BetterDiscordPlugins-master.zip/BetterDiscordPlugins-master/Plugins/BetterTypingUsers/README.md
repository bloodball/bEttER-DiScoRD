# BetterTypingUsers [![download](https://i.imgur.com/OAHgjZu.png)](https://1lighty.github.io/BetterDiscordStuff/?plugin=BetterTypingUsers&dl=1 "BetterTypingUsers")
Replaces "Several people are typing" with who is actually typing, plus "x others" if it can't fit. Number of shown people typing can be changed.
### Features
Several people are typing...  
is changed to  
**user 1**, **user 2**, **user 3** and **user 4** are typing  
or if it can't fit  
**user 1**, **user 2**, **user 3** and 3 others are typing  
It is 100% compatible with [BetterRoleColors](https://github.com/rauenzi/BetterDiscordAddons/tree/master/Plugins/BetterRoleColors) as well.
### Preview
![typing](https://i.imgur.com/HcPkMOx.png)
### Settings
##### Max visible typing users
Max number of visible users typing, can be set between 3 and 20. If more people are typing than this is set to, it will show "x others" instead.
