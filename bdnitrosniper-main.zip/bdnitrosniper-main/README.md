# bdnitrosniper
A simple nitro sniper for betterdiscord
