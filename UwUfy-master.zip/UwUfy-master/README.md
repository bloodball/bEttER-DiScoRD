A BetterDiscord plug-in that converts your messages to UwU language before sending them.
Credit to Metalloriff for working out how to edit messages before sending them in `TheClapBestClapPluginClapEver`.

### Contributing
Feel free to submit pull requests. You should change the `src/` files and upload the compiled JS to `dist/`. Do not commit only changes to `dist/`
