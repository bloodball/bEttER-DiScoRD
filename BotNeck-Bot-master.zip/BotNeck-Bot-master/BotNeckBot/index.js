const BotNeckBot = require('./core/BotNeckBot');

module.exports = { BotNeckBot }