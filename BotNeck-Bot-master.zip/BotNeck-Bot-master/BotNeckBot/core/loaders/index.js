const v2Loader = require('./v2Loader');
const GenericLoader = require('./GenericLoader');
const v3Loader = require('./v3Loader');

module.exports = { v2Loader, GenericLoader, v3Loader }