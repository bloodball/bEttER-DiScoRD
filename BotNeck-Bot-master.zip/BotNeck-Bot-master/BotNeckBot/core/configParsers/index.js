const BotNeckParser = require('./BotNeck');

module.exports = { BotNeckParser }