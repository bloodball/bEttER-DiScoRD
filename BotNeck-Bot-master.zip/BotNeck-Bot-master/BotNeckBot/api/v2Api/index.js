const { getModulesPath } = require('./BotNeckAPI');
const BotNeckAPI = require('./BotNeckAPI');
const v2Command = require('./v2Command');

module.exports = { BotNeckAPI, v2Command };